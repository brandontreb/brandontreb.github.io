//
//  PromotionTestViewController.m
//  PromotionTest
//
//  Created by Brandon Trebitowski on 11/25/10.
//  Copyright 2010 brandontreb.com. All rights reserved.
//

#import "PromotionTestViewController.h"
#import "PromotionViewController.h"

@implementation PromotionTestViewController

- (IBAction) moreAppsTouched:(id) sender {
	PromotionViewController *controller = [[PromotionViewController alloc]
										   initWithNibName:@"PromotionViewController" 
										   bundle:[NSBundle mainBundle]];
	controller.promotionAddress = @"http://brandontreb.com/apps/idevblogaday/promotion.html";
	[self presentModalViewController:controller animated:YES];
	[controller release];
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
