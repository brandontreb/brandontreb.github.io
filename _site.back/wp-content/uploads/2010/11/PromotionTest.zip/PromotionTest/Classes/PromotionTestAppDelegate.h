//
//  PromotionTestAppDelegate.h
//  PromotionTest
//
//  Created by Brandon Trebitowski on 11/25/10.
//  Copyright 2010 brandontreb.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PromotionTestViewController;

@interface PromotionTestAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    PromotionTestViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet PromotionTestViewController *viewController;

@end

