//
//  PromotionViewController.m
//  PromotionTest
//
//  Created by Brandon Trebitowski on 11/25/10.
//  Copyright 2010 brandontreb.com. All rights reserved.
//

#import "PromotionViewController.h"


@implementation PromotionViewController

@synthesize webView;
@synthesize spinner;
@synthesize promotionAddress;

- (void) viewWillAppear:(BOOL)animated {	
	
	// Create a URL from the address
	NSURL *url = [NSURL URLWithString:promotionAddress];
	
	// Creates the URL request to load in the webview
	NSURLRequest *request = [NSURLRequest requestWithURL:url];
	
	// Load the request in our webview
	[self.webView loadRequest:request];
	
	NSLog(@"will appear");
	
}

#pragma mark -
#pragma mark webView delegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request 
 navigationType:(UIWebViewNavigationType)navigationType {
	[spinner startAnimating];
	return YES;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
	[spinner stopAnimating];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" 
													message:@"Unable to load, please try again later." 
												   delegate:nil 
										  cancelButtonTitle:@"OK" 
										  otherButtonTitles:nil];
	[alert show];
	[alert release];
}

- (IBAction) doneButtonTouched:(id) sender {
	[self.parentViewController dismissModalViewControllerAnimated:YES];
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload {
    [super viewDidUnload];
    self.spinner = nil;
	self.webView = nil;
}


- (void)dealloc {
	[promotionAddress release];
    [super dealloc];
}


@end
