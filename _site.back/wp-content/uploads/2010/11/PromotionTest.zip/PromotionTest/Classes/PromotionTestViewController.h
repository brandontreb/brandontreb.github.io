//
//  PromotionTestViewController.h
//  PromotionTest
//
//  Created by Brandon Trebitowski on 11/25/10.
//  Copyright 2010 brandontreb.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PromotionTestViewController : UIViewController {

}

- (IBAction) moreAppsTouched:(id) sender;

@end

