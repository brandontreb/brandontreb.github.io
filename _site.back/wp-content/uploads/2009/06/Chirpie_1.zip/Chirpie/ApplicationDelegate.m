//
//  MainWindowController.m
//  Chirpie
//
//  Created by Brandon Trebitowski on 6/15/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "ApplicationDelegate.h"
#import "TwitterRequest.h"

@implementation ApplicationDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	TwitterRequest *tr = [[TwitterRequest alloc] init];
	tr.username = @"brandontreb";
	tr.password = @"someawesomepassword";
	NSLog(@"Getting timeline for user %@",tr.username);
	[tr friends_timeline:self requestSelector:@selector(friends_timeline_callback:)];
}

-(void) friends_timeline_callback:(NSData *)data {
	NSString *timeline = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
	NSLog(@"Timeline %@",timeline);
}
 

@end
