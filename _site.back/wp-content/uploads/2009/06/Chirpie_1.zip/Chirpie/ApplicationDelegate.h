//
//  MainWindowController.h
//  Chirpie
//
//  Created by Brandon Trebitowski on 6/15/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ApplicationDelegate : NSObject {

}

-(void) friends_timeline_callback:(NSData *)data;

@end
