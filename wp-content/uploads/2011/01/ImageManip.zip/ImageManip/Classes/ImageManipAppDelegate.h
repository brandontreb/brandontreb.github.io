//
//  ImageManipAppDelegate.h
//  ImageManip
//
//  Created by Brandon Trebitowski on 1/5/11.
//

#import <UIKit/UIKit.h>

@class ImageManipViewController;

@interface ImageManipAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    ImageManipViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet ImageManipViewController *viewController;

@end

