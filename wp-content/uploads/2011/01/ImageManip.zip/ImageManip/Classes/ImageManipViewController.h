//
//  ImageManipViewController.h
//  ImageManip
//
//  Created by Brandon Trebitowski on 1/5/11.
//

#import <UIKit/UIKit.h>

@interface ImageManipViewController : UIViewController<UIImagePickerControllerDelegate, UINavigationControllerDelegate> {
	UIImage *workingImage;
	IBOutlet UIImageView *imageView;
}

@property (nonatomic, retain) UIImage *workingImage;
@property (nonatomic, retain) IBOutlet UIImageView *imageView;

- (IBAction) chooseImage:(id) sender;
- (IBAction) grayscale:(id) sender;

@end

