<?php
/*
Plugin Name: Word Filter
Plugin URI: http://brandontreb.com/
Description: This plugin filters out certain words in a post.  Could be used as a swear word filter or just a global find and replace.
Version: 1.0
Author: Brandon Trebitowski
Author URI: http://brandontreb.com
*/

// Array of replacements
$search_array = array('idiot' => 'nice person', 'shutup' => 'please be quite', 'hate' => 'love');

// Make sure our fn gets called before displaying the content
add_filter('the_content','word_filter');

function word_filter($content) 
{
	global $search_array;
	
	// Modify the content
	foreach($search_array as $find => $replace)
	{
		$content = str_replace($find,$replace,$content);
	}
	
	// Return the content
	return $content;
}

?>