//
//  main.m
//  iChirpie
//
//  Created by Brandon Trebitowski on 12/8/10.
//  Copyright 2010 RightSprite. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
