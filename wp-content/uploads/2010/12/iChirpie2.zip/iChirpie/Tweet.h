//
//  Tweet.h
//  iChirpie
//
//  Created by Brandon Trebitowski on 12/9/10.
//  Copyright 2010 RightSprite. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface Tweet : NSObject {
	NSString *screenName;
	NSString *text;
}

@property(retain) NSString *screenName;
@property(retain) NSString *text;

@end
