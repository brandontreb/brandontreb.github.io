//
//  MGTwitterUserListsParser.h
//  MGTwitterEngine
//
//  Created by Clinton Shryock on 6/10/10.
//  Copyright 2010 scary-robot. All rights reserved.
//

#import "MGTwitterEngineGlobalHeader.h"

#import "MGTwitterStatusesParser.h"

@interface MGTwitterUserListsParser : MGTwitterStatusesParser {

}

@end
