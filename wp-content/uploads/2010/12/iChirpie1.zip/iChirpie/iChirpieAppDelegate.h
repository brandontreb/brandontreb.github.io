//
//  iChirpieAppDelegate.h
//  iChirpie
//
//  Created by Brandon Trebitowski on 12/8/10.
//  Copyright 2010 RightSprite. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface iChirpieAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
}

@property (assign) IBOutlet NSWindow *window;

@end
