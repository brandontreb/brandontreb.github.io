//
//  TweetsController.h
//  iChirpie
//
//  Created by Brandon Trebitowski on 12/8/10.
//  Copyright 2010 RightSprite. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class MGTwitterEngine;

@interface TweetsController : NSViewController<NSTabViewDelegate, NSTextViewDelegate>{
	IBOutlet NSTableView *tableView;
	IBOutlet NSTextView *tweetTextView;
	IBOutlet NSTextField *tweetCountLabel;
	NSMutableArray *tweets;
	MGTwitterEngine *twitterEngine;
}

@property (retain) IBOutlet NSTableView *tableView;
@property (retain) IBOutlet NSTextView *tweetTextView;
@property (retain) IBOutlet NSTextField *tweetCountLabel;
@property (retain) NSMutableArray *tweets;
@property (retain) MGTwitterEngine *twitterEngine;

- (void) refreshTweets;
- (IBAction) tweetButtonClicked:(id) sender;

@end
