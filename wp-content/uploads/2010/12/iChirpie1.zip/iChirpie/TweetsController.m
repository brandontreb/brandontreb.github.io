//
//  TweetsController.m
//  iChirpie
//
//  Created by Brandon Trebitowski on 12/8/10.
//  Copyright 2010 RightSprite. All rights reserved.
//

#import "TweetsController.h"
#import "MGTwitterEngine.h"
#import "Tweet.h"

@implementation TweetsController

@synthesize tableView;
@synthesize tweets;
@synthesize tweetTextView;
@synthesize tweetCountLabel;
@synthesize twitterEngine;

- (void)awakeFromNib {
	self.tweets = [[NSMutableArray alloc] init];
	
	OAToken *token = [[OAToken alloc] initWithKey:@"16369316-GgqA00WO0poCAj0XAFhJYDDRthVvWMxTnVyKdfWa1" 
										   secret:@"MbzvWMTGRgMr8fBvOxiSHHjUtNJDGo73z5hFAhA"];;
	
	// Put your Twitter username and password here:
    NSString *username = @"brandontreb";	
	NSString *consumerKey = @"aKKEsJHTDNsv4xVlMHmMqw";
	NSString *consumerSecret = @"ifBbpOPnQh3DmvfrkPvTJ9GDxi56WB6TczsE8KhvA";
	
    // Create a TwitterEngine and set our login details.
    self.twitterEngine = [[[MGTwitterEngine alloc] initWithDelegate:self] autorelease];
	[twitterEngine setUsesSecureConnection:NO];
	[twitterEngine setConsumerKey:consumerKey secret:consumerSecret];
	[twitterEngine setUsername:username];	
	[twitterEngine setAccessToken:token];
	[self refreshTweets];
}

#pragma mark -
#pragma mark Twitter calls
- (void) refreshTweets {
	[twitterEngine getHomeTimelineSinceID:0 startingAtPage:0 count:20];
}

#pragma mark -
#pragma mark Actions
- (IBAction) tweetButtonClicked:(id) sender {
	[twitterEngine sendUpdate:[tweetTextView string]];
	[tweetTextView setString:@""];
}

#pragma mark -
#pragma mark MGTwitterEngineDelegate
- (void)statusesReceived:(NSArray *)statuses forRequest:(NSString *)connectionIdentifier {
	
	if([statuses count] == 1) { // when user updates their status
		NSDictionary *tweetDict = [statuses objectAtIndex:0];
		NSString *screenName = [[tweetDict objectForKey:@"user"] objectForKey:@"screen_name"];
		NSString *text = [tweetDict objectForKey:@"text"];
		Tweet *tweet = [[Tweet alloc] init];
		tweet.screenName = screenName;
		tweet.text = text;
		[self.tweets insertObject:tweet atIndex:0];
		[tweet release];
	} else {
		for(NSDictionary *tweetDict in statuses) {
			NSString *screenName = [[tweetDict objectForKey:@"user"] objectForKey:@"screen_name"];
			NSString *text = [tweetDict objectForKey:@"text"];
			Tweet *tweet = [[Tweet alloc] init];
			tweet.screenName = screenName;
			tweet.text = text;
			[self.tweets addObject:tweet];
			[tweet release];
		}
	}
	
	[self.tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO];
}

#pragma mark -
#pragma mark TableView Data Source
- (NSInteger)numberOfRowsInTableView:(NSTableView *)aTableView {
	return [self.tweets count];
}

- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex {
	return nil;
}

#pragma mark -
#pragma mark TableView Delegate
- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row {
	return 50.0;
}

- (void)tableView:(NSTableView *)aTableView willDisplayCell:(id)aCell forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex {
	Tweet *tweet = [self.tweets objectAtIndex:rowIndex];
	[aCell setTitle:[NSString stringWithFormat:@"%@: %@",tweet.screenName,tweet.text]];
	[aCell setWraps:YES];
}

#pragma mark -
#pragma mark NSTextField Delegate
- (BOOL)textView:(NSTextView *)aTextView shouldChangeTextInRange:(NSRange)affectedCharRange replacementString:(NSString *)replacementString {
	NSString *text = [tweetTextView string];
	int length = [text length] + 1;
	[tweetCountLabel setStringValue:[NSString stringWithFormat:@"%d",(140 - length)]];
	// Allows user to delete characters
	if([replacementString length] == 0) return YES;
	return length < 140;
}

- (void) dealloc {
	[tableView release];
	[tweetTextView release];
	[tweets release];
	[tweetCountLabel release];
	[twitterEngine release];
	[super dealloc];
}

@end
