//
//  TweetsController.m
//  iChirpie
//
//  Created by Brandon Trebitowski on 12/8/10.
//  Copyright 2010 RightSprite. All rights reserved.
//

#import "TweetsController.h"
#import "MGTwitterEngine.h"
#import "Tweet.h"

@implementation TweetsController

@synthesize tableView;
@synthesize tweets;

- (void)awakeFromNib {
	self.tweets = [[NSMutableArray alloc] init];
	
	MGTwitterEngine *twitterEngine = [MGTwitterEngine twitterEngineWithDelegate:self];
	OAToken *token = [[OAToken alloc] initWithKey:@"" 
										   secret:@""];;
	
	// Put your Twitter username and password here:
    NSString *username = @"";	
	NSString *consumerKey = @"";
	NSString *consumerSecret = @"";
	
    // Create a TwitterEngine and set our login details.
    twitterEngine = [[MGTwitterEngine alloc] initWithDelegate:self];
	[twitterEngine setUsesSecureConnection:NO];
	[twitterEngine setConsumerKey:consumerKey secret:consumerSecret];
	[twitterEngine setUsername:username];	
	[twitterEngine setAccessToken:token];
	
	[twitterEngine getHomeTimelineSinceID:0 startingAtPage:0 count:20];
}

#pragma mark -
#pragma mark MGTwitterEngineDelegate
- (void)statusesReceived:(NSArray *)statuses forRequest:(NSString *)connectionIdentifier {
	NSLog(@"CAllbac with statuses %@", statuses);
	for(NSDictionary *tweetDict in statuses) {
		NSString *screenName = [[tweetDict objectForKey:@"user"] objectForKey:@"screen_name"];
		NSString *text = [tweetDict objectForKey:@"text"];
		Tweet *tweet = [[Tweet alloc] init];
		tweet.screenName = screenName;
		tweet.text = text;
		[self.tweets addObject:tweet];
		[tweet release];
	}
	
	[self.tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO];
}

#pragma mark -
#pragma mark TableView Data Source
- (NSInteger)numberOfRowsInTableView:(NSTableView *)aTableView {
	return [self.tweets count];
}

- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex {
	return nil;
}

#pragma mark -
#pragma mark TableView Delegate
- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row {
	return 50.0;
}

- (void)tableView:(NSTableView *)aTableView willDisplayCell:(id)aCell forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex {
	Tweet *tweet = [self.tweets objectAtIndex:rowIndex];
	[aCell setTitle:[NSString stringWithFormat:@"%@: %@",tweet.screenName,tweet.text]];
	[aCell setWraps:YES];
}

- (void) dealloc {
	[tableView release];
	[tweets release];
	[super dealloc];
}

@end
