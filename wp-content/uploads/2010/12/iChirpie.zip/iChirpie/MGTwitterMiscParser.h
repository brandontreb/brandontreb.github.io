//
//  MGTwitterMiscParser.h
//  MGTwitterEngine
//
//  Created by Matt Gemmell on 06/06/2008.
//  Copyright 2008 Instinctive Code. All rights reserved.
//

#import "MGTwitterEngineGlobalHeader.h"

#import "MGTwitterStatusesParser.h"

@interface MGTwitterMiscParser : MGTwitterStatusesParser {
	
}

@end
