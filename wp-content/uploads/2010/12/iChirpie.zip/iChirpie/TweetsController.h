//
//  TweetsController.h
//  iChirpie
//
//  Created by Brandon Trebitowski on 12/8/10.
//  Copyright 2010 RightSprite. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TweetsController : NSViewController<NSTabViewDelegate>{
	IBOutlet NSTableView *tableView;	
	NSMutableArray *tweets;
}

@property (retain) IBOutlet NSTableView *tableView;
@property (retain) NSMutableArray *tweets;

@end
