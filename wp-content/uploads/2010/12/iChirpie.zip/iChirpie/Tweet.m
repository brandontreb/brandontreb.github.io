//
//  Tweet.m
//  iChirpie
//
//  Created by Brandon Trebitowski on 12/9/10.
//  Copyright 2010 RightSprite. All rights reserved.
//

#import "Tweet.h"


@implementation Tweet

@synthesize screenName;
@synthesize text;

- (id)copyWithZone:(NSZone *)zone {
    return self;
}

- (void) dealloc {
	[screenName release];
	[text release];
	[super dealloc];
}

@end
