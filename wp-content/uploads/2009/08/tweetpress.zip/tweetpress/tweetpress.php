<?php
	/*
	Plugin Name: TweetPress
	Plugin URI: http://brandontreb.com/tweetpress
	Description: A plugin that allows you to take control of your Twitter images
	Version: 1.0
	Author: Brandon Trebitowski
	Author URI: http://brandontreb.com/tweetpress
	
	
	Copyright 2009  Brandon Trebitowski  (email : brandontreb@gmail.com)
	
	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
	
	Todo: Filter Comments by image
	
	*/

	define('THUMBSIZE',100);

	if (!defined('PLUGINDIR')) {
		define('PLUGINDIR','wp-content/plugins');
	}
	
	if (!defined('UPLOADDIR')) {
		define('UPLOADDIR',ABSPATH . 'wp-content/');
	}
	
	if (!defined('GALLERYPATH')) {
		define('GALLERYPATH','/wp-content/tweetpress');
	}
	/*
	 * Global Settings
	 */
	
	$data = array(
		'page_id'				=> 0,
		'requires_wp_auth'	    => true,
		'recent_photo_limit'	=> 5,
		'configured'			=> 0
		);
	
	add_option('tp_settings',$data,'TweetPress Replacement Options');
	
	$tp_settings = get_option('tp_settings');
	
	function tp_css() {
		$stylesheet_url = get_bloginfo ( 'url' ) . '/' .PLUGINDIR.'/tweetpress/tweetpress.css';
		echo '<link rel="stylesheet" href="' . $stylesheet_url . '" type="text/css" />';
	}
	add_action( 'wp_head', 'tp_css' );
	
	/*
	 * Admin menu
	 */
	add_action('admin_menu', 'tp_menu');
	
	function tp_menu() {
	  add_options_page('TweetPress Options', 'TweetPress', 8, __FILE__, 'tp_options');
	}
	function tp_options() {
		global $_POST,$tp_settings;
		
		if($tp_settings['configured'] == 0) {
			$tp_settings['configured'] = 1;
			update_option('tp_settings',$tp_settings);
		}
		
		if(isset($_POST['page_id'])) {
			$tp_settings['page_id'] = $_POST['page_id'];
			$tp_settings['requires_wp_auth'] = isset($_POST['tp_requires_wp_auth']);
			
			update_option('tp_settings',$tp_settings);
		}
		
		if(is_writable(UPLOADDIR)) {
			if(!is_dir(UPLOADDIR . 'tweetpress')) {
				$success = mkdir(UPLOADDIR . 'tweetpress');
			}
			
			if(!is_dir(UPLOADDIR . 'tweetpress/thumbs')) {
				mkdir(UPLOADDIR . 'tweetpress/thumbs');
			}
		}
		$pages = get_pages(); 
		
		echo '<div class="wrap" id="tp-options">';
	  	echo '<h2>TweetPress Options</h2>';
	  
	  	echo '<form action="" method="post">
	  			<table cellpadding="10" cellspacing="10">
	  				<tr>
	  					
  						<td align="right" width="200">
			  				<label for="page_id">Gallery Page:</label>
			  			</td>
			  			<td>
	  						<select name="page_id">
	  							<option value="0">Homepage</option>';
	  							foreach($pages as $page) {
	  								echo '<option value="'.$page->ID.'"';
	  								if($page->ID == $tp_settings['page_id']) {
	  									echo ' selected="selected" ';
	  								}
	  								echo '>'.$page->post_title.'</option>';
	  							}	
	  					
	  	echo '				</select>
	  					</td>
	  				</tr>
	  				<tr>
  						<td>Posting Requires a Wordpress account</td>
  						<td><input type="checkbox" name="tp_requires_wp_auth" '.($tp_settings['requires_wp_auth'] ? 'checked="checked"' : "").' ></td>
  					</tr>
	  				<tr>
  						<td>&nbsp;</td>
  						<td><input type="submit" name="tp_submit" value="Save Settings" ></td>
  					</tr>
	  			</table>
	  			</form>';
		
	}

	/*
	 * Displaying the Gallery
	 */
	 
	add_action('get_header', 'check_gallery_path',0);

	function check_gallery_path() {
		global $tp_settings,$wp_query;
		
		if($tp_settings['page_id'] != 0 && isset($_GET['image_id'])) {
			if(!isset($_GET['page_id'])) {
				if($wp_query->post->ID != $tp_settings['page_id']) {
					$gallery_url = get_bloginfo ( 'url' ) . '/?' . $_SERVER['QUERY_STRING'] . '&page_id=' . $tp_settings['page_id'];
					header("Location: $gallery_url");
					exit;
				}
			}	
		}
	}

	function load_gallery_on_page() {
		global $db,$wp_query,$tp_settings;
		if($tp_settings['page_id'] != 0) {
			if($wp_query->post->ID == $tp_settings['page_id']	) {
				add_filter('the_content','load_gallery');
			}
		} else if(is_home() || is_front_page()) {
			add_action('loop_start','load_gallery_home');
		}
	}
	
	function load_gallery($content) {
		require(PLUGINDIR . '/tweetpress/gallery.php');
		return tp_gallery() . $content;
	}
	
	function load_gallery_home() {
		require(PLUGINDIR . '/tweetpress/gallery.php');
		echo tp_gallery();
	}

	add_action('get_header','load_gallery_on_page');

	/*
	 * API
	 */
	 
	add_action('plugins_loaded', 'tp_upload',-1);
	
	function tp_upload() {
		global $wpdb,$tp_settings,$_POST,$_GET,$_SERVER,$_FILES;
		
		// for ping requests
		if(isset($_GET['tp_ping'])) {
		
			if(isset($_REQUEST['username']) && isset($_REQUEST['password']) && $tp_settings['requires_wp_auth']) {
				if(validate_credentials($_REQUEST['username'],$_REQUEST['password'])) {			
					echo '<?xml version="1.0" encoding="UTF-8"?>
					<rsp stat="ok">
					    <message>TweetPress plugin successfully installed</message>
					</rsp>';
				} else {
					returnError(1,"Invalid username or password");
				}
			} else {
				echo '<?xml version="1.0" encoding="UTF-8"?>
					<rsp stat="ok">
					    <message>TweetPress successfully installed</message>
					</rsp>';
			}
			exit(0);
		}
		
		if(isset($_FILES['media']))  {
		
			
			if($tp_settings['requires_wp_auth']) {
				if(isset($_REQUEST['username']) && isset($_REQUEST['password'])) {
					if(!validate_credentials($_REQUEST['username'],$_REQUEST['password'])) {
						returnError(1,"Invalid username or password");
						exit;
					}
				} else {
					returnError(1,"Username or password not specified");
					exit;
				}
			}
			
			
			if(!isset($_FILES) || !array_key_exists('tmp_name', $_FILES['media'])) {
				returnError(2,"No image provided");
				exit;
			} 
			
			require(PLUGINDIR . '/tweetpress/b1t.me.class.php');
			
			// Localize the variables
			$fileName = $_FILES['media']['name'];
			$tmpName  = $_FILES['media']['tmp_name'];
			$fileSize = $_FILES['media']['size'];
			
			// Get the file type
			$typeArray = explode(".",$fileName);
			$fileType  = "image/" . $typeArray[1];
			
			if($fileType != "image/png" && $fileType != "image/jpg" && $fileType != "image/jpeg" && $fileType != "image/tiff") {
				returnError(3,"Invalid image type");
				exit;
			}
			
			// Resolve the path
			$uploadDir  = UPLOADDIR . '/tweetpress/';
			$fileName   = basename($fileName);
			$uploadFile = $uploadDir . $fileName;
		
			// Give a unique name if file exists
			if(file_exists($uploadFile)) {
				$fileName   = date('YmdHis') . $fileName;
				$uploadFile = $uploadDir . $fileName;
			}
			
			// Update the database
			$table_name = $wpdb->prefix . "tweetpress";
			$wpdb->query($wpdb->prepare("INSERT INTO $table_name (type,name,size,message,latitude,longitude) VALUES('%s','%s','%d','%s','%s','%s')",
				$fileType,$fileName,$fileSize,$_POST['message'],$_POST['latitude'],$_POST['longitude']));
			
			// Save file to disk
			if (move_uploaded_file($_FILES['media']['tmp_name'], $uploadFile)) {
			
				// thumbnail
				if(function_exists("wp_crop_image")) {
					wp_crop_image( '.' . GALLERYPATH . '/' . $fileName, 0,0, 500, 500, THUMBSIZE, THUMBSIZE,false,  '.' . GALLERYPATH . '/thumbs/' . $fileName );
				} else {
					copy($uploadFile,UPLOADDIR . '/tweetpress/thumbs/' . $fileName);
				}
			
				$b1tme = null;
				
				if($tp_settings['page_id'] == 0) {
					$b1tme = new b1tme(get_bloginfo ( 'url' ) . '?image_id=' . $wpdb->insert_id);
				} else {
					$b1tme = new b1tme(get_bloginfo ( 'url' ) . '?p=' . $tp_settings['page_id'] . '&image_id=' . $wpdb->insert_id);
				}
							
				$imageurl = get_bloginfo ( 'url' ) . GALLERYPATH . '/' . $fileName;
				$thumburl = get_bloginfo ( 'url' ) . GALLERYPATH . '/thumbs/' . $fileName;
				
				echo '<?xml version="1.0" encoding="UTF-8"?>
				<rsp stat="ok">
				 <mediaid>'.$wpdb->insert_id.'</mediaid>
				 <mediaurl>'.$b1tme->shorten().'</mediaurl>
				 <imageurl>'.$imageurl.'</imageurl>
				 <thumburl>'.$thumburl.'</thumburl>
				</rsp>';

				
			} else {
				returnError(4,"Unable to write image to disk");
			}
			
			exit;
		}
		
	}
	
	function validate_credentials($username, $password) {
		return user_pass_ok($username,$password);
	}
	
	function returnError($code,$message) {
		echo str_replace("\t",'','<?xml version="1.0" encoding="UTF-8"?>
			<rsp stat="fail">
			<err code="'.$code.'" msg="'.$message.'" />
			</rsp>');
	}
	
	/*
	 * Install 
	 */
	 
	 function tp_activate () {
	 	global $wpdb;
		
		$table_name = $wpdb->prefix . "tweetpress";
		
		if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
			echo "creating";
			$sql = "CREATE TABLE `".$table_name."` (
				`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
				`type` VARCHAR( 25 ) NOT NULL ,
				`name` VARCHAR( 25 ) NOT NULL ,
				`size` VARCHAR( 25 ) NOT NULL ,
				`message` VARCHAR( 150 ) NULL ,
				`latitude` VARCHAR( 25 ) NOT NULL ,
				`longitude` VARCHAR( 25 ) NOT NULL ,
				`time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
				)";
		
			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta($sql);
		}
		if(is_writable(UPLOADDIR)) {
			if(!is_dir(UPLOADDIR . 'tweetpress')) {
				$success = mkdir(UPLOADDIR . 'tweetpress');
			}
			
			if(!is_dir(UPLOADDIR . 'tweetpress/thumbs')) {
				mkdir(UPLOADDIR . 'tweetpress/thumbs');
			}
		}
	}
	register_activation_hook( __FILE__, 'tp_activate' );
	
	
	function tp_admin_notice() {
		global $tp_settings;
		if($tp_settings['configured'] != 1) {
			echo '<div class="error"><p><strong>' . sprintf( __('TweetPress is not configured. Please go to the <a href="%s">plugin admin page</a> to configure it. ' ), admin_url( 'options-general.php?page=tweetpress/tweetpress.php' ) ) . '</strong></p></div>';
		}
		
		if(!is_writable(UPLOADDIR)) {
			echo '<div class="error"><p><strong>' . UPLOADDIR . ' is not writable! This directory must be writable for TweetPress to work. Contact an administrator if you are unsure about how to do this.' . '</strong></p></div>';
		}
		
	}
	add_action( 'admin_notices', 'tp_admin_notice' );
	
?>