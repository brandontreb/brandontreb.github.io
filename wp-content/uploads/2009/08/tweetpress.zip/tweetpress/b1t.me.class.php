<?php
	class b1tme {
		//http://b1t.me/api/shorten.json/http://brandontreb.com
		var $url;
		
		function b1tme($url) {
			$this->url = $url;
		}
		
		function shorten() {
			$curl_handle=curl_init();
			curl_setopt($curl_handle,CURLOPT_URL,"http://b1t.me/api/shorten.xml/" . $this->url);
			curl_setopt($curl_handle,CURLOPT_CONNECTTIMEOUT,2);
			curl_setopt($curl_handle,CURLOPT_RETURNTRANSFER,1);
			$buffer = curl_exec($curl_handle);
			curl_close($curl_handle);
			
			if (empty($buffer))
			{
			    return $url;
			}
			else
			{
			    return $this->value_in('shorturl',$buffer); 
			}

		}
		
		function value_in($element_name, $xml, $content_only = true) {
		    if ($xml == false) {
		        return false;
		    }
		    $found = preg_match('#<'.$element_name.'(?:\s+[^>]+)?>(.*?)'.
		            '</'.$element_name.'>#s', $xml, $matches);
		    if ($found != false) {
		        if ($content_only) {
		            return $matches[1];  //ignore the enclosing tags
		        } else {
		            return $matches[0];  //return the full pattern match
		        }
		    }
		    // No match found: return false.
		    return false;
		}

	}
?>