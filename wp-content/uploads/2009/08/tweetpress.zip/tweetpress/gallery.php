<?php

	function tp_gallery() {
		global $wpdb,$_GET,$tp_settings;
		
		$mainImage = null;
		$table_name = $wpdb->prefix . "tweetpress";
		
		if(isset($_GET['image_id'])) {
			$mainImage = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d",$_GET['image_id']));
		} else {
			$mainImage = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id IN (SELECT MAX(id) FROM $table_name)"));
		}
		
		$recentImages = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE id != %d ORDER BY id DESC LIMIT %d",$mainImage->id,5));
		
		$post_string = "?";
		if($tp_settings['page_id'] != 0) {
			$post_string = "?p=" . $tp_settings['page_id'] . "&";
		}
		
		$return = '<div id="tweetpress">';
			$return .= '<div id="tp-main">';
				$return .= '<img class="tp-main-image" src="'.get_bloginfo ( 'url' ).'/'.GALLERYPATH.'/'.$mainImage->name.'">';
				$return .= '<div id="tp-main-message">'.$mainImage->message.'</div>';
			$return .= '</div>';
			$return .= '<div id="tp-recent-images">';
				$return .= '<ul id="tp-recent-images-list">';	
				foreach($recentImages as $image) {
					$return .= '<li><a href="'.get_bloginfo ( 'url' ). $post_string .'image_id='.$image->id.'"><img class="tp-recent-image" src="'.get_bloginfo ( 'url' ).'/'.GALLERYPATH.'/thumbs/'.$image->name.'" width='.THUMBSIZE.' height='.THUMBSIZE.'></a></li>';
				}
				$return .= '</ul>';
			$return .= '</div>';
			$return .= '<div class="clear">&nbsp;</div>';
		$return .= '</div>';

		return $return;
	}

?>