//
//  MainWindowController.m
//  Chirpie
//
//  Created by Brandon Trebitowski on 6/15/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "ApplicationDelegate.h"
#import "TwitterRequest.h"

@implementation ApplicationDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	TwitterRequest *tr = [[TwitterRequest alloc] init];
	tr.username = @"Twitter Username";
	tr.password = @"Twitter Password";
	NSLog(@"Getting timeline for user %@",tr.username);
	//[tr friends_timeline:self requestSelector:@selector(friends_timeline_callback:)];

	NSLog(@"Updating Status for user %@",tr.username);
	[tr statuses_update:@"Writing part 2 of my Twitter client programming tutorial on http://brandontreb.com" 
			   delegate:self requestSelector:@selector(friends_timeline_callback:)];
}
	
-(void) statuses_update_callback:(NSData *)data {
	NSLog(@"%@",[[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding]);
}

-(void) friends_timeline_callback:(NSData *)data {
	NSString *timeline = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
	NSLog(@"Timeline %@",timeline);
}
 

@end
